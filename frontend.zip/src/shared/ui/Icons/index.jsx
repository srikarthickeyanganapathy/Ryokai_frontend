/* eslint-disable react-refresh/only-export-components */
import {
  AlertCircle,
  CheckCircle2,
  X,
  ChevronRight,
  ChevronLeft,
  ChevronDown,
  ChevronUp,
  Search,
  Settings,
  User,
  LogOut,
  Moon,
  Sun,
  LayoutDashboard,
  CheckSquare,
  Users,
  Briefcase,
  Check,
  Menu,
  ListTodo,
  FolderClosed,
  BarChart2,
  Building2,
  Plus,
  Loader2,
  Trash2,
  Shield
} from 'lucide-react'

const GithubIcon = ({ className, ...props }) => (
  <svg
    className={className}
    {...props}
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M15 22v-4a4.8 4.8 0 0 0-1-3.03c3.15-.38 6.5-1.54 6.5-7.17 0-1.58-.56-2.9-1.5-3.93.15-.38.65-1.86-.15-3.87 0 0-1.2-.38-3.9 1.45a13.5 13.5 0 0 0-7 0c-2.7-1.83-3.9-1.45-3.9-1.45-.8 2.01-.3 3.49-.15 3.87-1 1.03-1.5 2.35-1.5 3.93 0 5.61 3.33 6.78 6.5 7.15A4.8 4.8 0 0 0 8 18v4"></path>
  </svg>
)

const GoogleIcon = ({ className, ...props }) => (
  <svg
    className={className}
    {...props}
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="currentColor"
  >
    <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" />
    <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
    <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05" />
    <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" />
  </svg>
)

// Centralized icon exports for standardizing sizes and stroke widths later if needed
export const Icons = {
  alert: AlertCircle,
  success: CheckCircle2,
  close: X,
  x: X,
  chevronRight: ChevronRight,
  chevronLeft: ChevronLeft,
  chevronDown: ChevronDown,
  chevronUp: ChevronUp,
  search: Search,
  settings: Settings,
  user: User,
  logout: LogOut,
  moon: Moon,
  sun: Sun,
  dashboard: LayoutDashboard,
  tasks: CheckSquare,
  team: Users,
  users: Users,
  projects: Briefcase,
  github: GithubIcon,
  google: GoogleIcon,
  check: Check,
  menu: Menu,
  layoutDashboard: LayoutDashboard,
  checkCircle: CheckCircle2,
  listTodo: ListTodo,
  folderClosed: FolderClosed,
  barChart2: BarChart2,
  building: Building2,
  workspace: Building2,
  plus: Plus,
  spinner: Loader2,
  trash2: Trash2,
  shield: Shield,
}
