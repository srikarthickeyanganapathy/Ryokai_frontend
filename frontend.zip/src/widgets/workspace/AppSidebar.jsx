import React from 'react'
import { NavLink } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { Icons } from '@/shared/ui/Icons'
import { Text } from '@/shared/ui/Typography'
import { cn } from '@/shared/lib/cn'
import { useAuth } from '@/features/auth/hooks/useAuth'
import { useWorkspace } from '@/context/WorkspaceContext'
import { usePermissions } from '@/context/usePermissions'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/shared/ui/Select'
import { Popover, PopoverTrigger, PopoverContent } from '@/shared/ui/Popover'
import { Separator } from '@/shared/ui/Separator'
import { useNavigate, useLocation, Link } from 'react-router-dom'
import { Avatar, AvatarFallback, AvatarImage } from '@/shared/ui/Avatar'

export function AppSidebar({ isOpen, onClose }) {
  const { user, logout } = useAuth()
  const { workspaceMode, setWorkspaceMode, activeOrganization, setActiveOrganization, organizations } = useWorkspace()
  const { isSuperAdmin } = usePermissions()
  const location = useLocation()
  const navigate = useNavigate()
  const [userMenuOpen, setUserMenuOpen] = React.useState(false)

  const isSettingsMode = location.pathname.startsWith('/app/settings') || location.pathname.startsWith('/app/sessions')

  const primaryItems = [
    { icon: Icons.layoutDashboard, label: 'Dashboard', to: '/app' },
    { icon: Icons.checkCircle, label: 'Focus', to: '/app/focus' },
    { icon: Icons.listTodo, label: 'Tasks', to: '/app/tasks' },
  ]

  const workspaceItems = [
    { icon: Icons.folderClosed, label: 'Projects', to: '/app/projects' },
    { icon: Icons.building, label: 'Organizations', to: '/app/organizations' },
    { icon: Icons.barChart2, label: 'Analytics', to: '/app/analytics' },
    ...(isSuperAdmin ? [{ icon: Icons.shield, label: 'Admin', to: '/app/admin' }] : []),
  ]

  const settingsNavItems = [
    { icon: Icons.user, label: 'Profile', to: '/app/settings/profile' },
    { icon: Icons.shield, label: 'Security', to: '/app/settings/security' },
    { icon: Icons.settings, label: 'Sessions', to: '/app/settings/sessions' },
  ]

  const renderNavSection = (items, title) => (
    <div className="space-y-1 mb-6">
      {title && (
        <div className="px-3 pb-2">
          <span className="text-[11px] font-medium text-[var(--text-tertiary)]">{title}</span>
        </div>
      )}
      <div className="space-y-[2px] px-2">
        {items.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.to === '/app'}
            className={({ isActive }) => cn(
              "relative flex items-center gap-3 px-3 h-[34px] rounded-full text-[13px] font-medium transition-colors duration-150 group",
              isActive
                ? "text-[var(--accent)]"
                : "text-[var(--text-secondary)] hover:text-[var(--text-primary)] hover:bg-[var(--bg-hover)]"
            )}
          >
            {({ isActive }) => (
              <>
                {isActive && (
                  <motion.div
                    layoutId="sidebar-active-pill"
                    className="absolute inset-0 rounded-full bg-[var(--accent-soft)]"
                    transition={{ type: 'spring', stiffness: 500, damping: 38, mass: 0.6 }}
                  />
                )}
                <item.icon className={cn("relative w-[16px] h-[16px]", isActive ? "text-[var(--accent)]" : "text-[var(--text-tertiary)] group-hover:text-[var(--text-secondary)]")} strokeWidth={2} />
                <span className="relative">{item.label}</span>
              </>
            )}
          </NavLink>
        ))}
      </div>
    </div>
  )

  const sidebarContent = (
    <div className="flex flex-col h-full bg-[var(--bg-base)] w-64 relative z-20">
      
      {/* Brand Header */}
      <div className="h-14 flex items-center justify-between px-4">
        <div className="flex items-center gap-2 text-[var(--text-primary)] cursor-pointer" onClick={() => navigate('/app')}>
          <div className="w-6 h-6 rounded-[var(--radius-sm)] bg-gradient-to-b from-[var(--accent-hover)] to-[var(--accent-active)] flex items-center justify-center">
            <Icons.dashboard className="w-3.5 h-3.5 text-white" />
          </div>
          <span className="text-[15px] font-medium tracking-[-0.01em]">Ryokai</span>
        </div>
        <button className="text-[var(--text-tertiary)] hover:text-[var(--text-primary)] transition-colors">
          <Icons.menu className="w-4 h-4" />
        </button>
      </div>

      {/* Main Navigation */}
      <div className="flex-1 py-4 overflow-y-auto custom-scrollbar">

        {!isSettingsMode && (
          <>
            {renderNavSection(primaryItems, 'Primary')}
            {renderNavSection(workspaceItems, 'Workspace')}
            
            <div className="px-4 mt-6">
              <Select
                value={workspaceMode === 'ORG' && activeOrganization ? activeOrganization.id.toString() : 'PERSONAL'}
                onValueChange={(val) => {
                  if (val === 'PERSONAL') {
                    setWorkspaceMode('PERSONAL')
                  } else {
                    const org = organizations.find(o => o.id.toString() === val)
                    if (org) {
                      setWorkspaceMode('ORG')
                      setActiveOrganization(org)
                    }
                  }
                }}
              >
                <SelectTrigger className="w-full bg-transparent border-[var(--border-subtle)] h-8 text-[12px] rounded-full px-3">
                  <SelectValue placeholder="Select Workspace" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="PERSONAL">
                    <div className="flex items-center gap-2">
                      <Icons.user className="w-4 h-4" />
                      <span>Personal Space</span>
                    </div>
                  </SelectItem>
                  {organizations.map(org => (
                    <SelectItem key={org.id} value={org.id.toString()}>
                      <div className="flex items-center gap-2">
                        <Icons.building className="w-4 h-4" />
                        <span>{org.name}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </>
        )}

        {isSettingsMode && (
          <>
            <div className="px-4 pb-4 flex items-center gap-2">
              <button 
                onClick={() => navigate('/app')}
                className="text-[var(--text-secondary)] hover:text-[var(--text-primary)] p-1 rounded-full hover:bg-[var(--bg-hover)] transition-colors"
              >
                <Icons.chevronLeft className="w-4 h-4" />
              </button>
              <span className="text-[13px] font-medium text-[var(--text-primary)]">Settings</span>
            </div>
            {renderNavSection(settingsNavItems, 'Account')}
          </>
        )}
      </div>

      {/* User Footer (Gemini Style) */}
      <div className="p-3">
        <Popover open={userMenuOpen} onOpenChange={setUserMenuOpen}>
          <PopoverTrigger asChild>
            <div className="flex items-center justify-between px-2 py-2 rounded-full hover:bg-[var(--bg-hover)] transition-colors cursor-pointer group">
              <div className="flex items-center gap-2.5 min-w-0">
                <Avatar size="sm" className="bg-[#B8720A] text-white">
                  <AvatarImage src={user?.avatarUrl} />
                  <AvatarFallback className="bg-[#B8720A] text-white">{user?.name?.charAt(0) || user?.username?.charAt(0) || 'U'}</AvatarFallback>
                </Avatar>
                <div className="flex flex-col min-w-0">
                  <Text className="text-[13px] font-medium truncate text-[var(--text-primary)] leading-tight">{user?.name || user?.username}</Text>
                  <Text className="text-[11px] truncate text-[var(--text-secondary)] leading-tight">Pro</Text>
                </div>
              </div>
              <button 
                onClick={(e) => {
                  e.stopPropagation()
                  navigate('/app/settings/profile')
                }}
                className="text-[var(--text-tertiary)] hover:text-[var(--text-primary)] p-1.5 rounded-full transition-colors opacity-0 group-hover:opacity-100"
              >
                <Icons.settings className="w-4 h-4" />
              </button>
            </div>
          </PopoverTrigger>
          <PopoverContent align="start" side="top" className="w-56 p-1.5" sideOffset={8}>
            <div className="px-2 py-1.5">
              <Text className="font-medium text-[13px]">{user?.name || user?.username}</Text>
              {user?.email && (
                <Text variant="muted" size="xs" className="truncate">{user.email}</Text>
              )}
            </div>
            <Separator className="my-1" />
            <div className="space-y-0.5">
              <Link
                to="/app/settings/profile"
                onClick={() => setUserMenuOpen(false)}
                className="flex items-center gap-2 px-2 h-7 text-[13px] rounded-[var(--radius-sm)] hover:bg-[var(--bg-hover)] text-[var(--text-secondary)] hover:text-[var(--text-primary)] transition-colors w-full"
              >
                <Icons.settings className="w-3.5 h-3.5" />
                Settings
              </Link>
              <button
                onClick={async () => {
                  setUserMenuOpen(false)
                  await logout()
                  navigate('/login')
                }}
                className="flex items-center gap-2 px-2 h-7 text-[13px] rounded-[var(--radius-sm)] hover:bg-[var(--danger-soft)] text-[var(--text-secondary)] hover:text-[var(--danger)] transition-colors w-full text-left"
              >
                <Icons.x className="w-3.5 h-3.5" />
                Logout
              </button>
            </div>
          </PopoverContent>
        </Popover>
      </div>
    </div>
  )

  return (
    <>
      {/* Desktop Persistent Sidebar */}
      <div className="hidden lg:block h-full">
        {sidebarContent}
      </div>

      {/* Mobile Drawer Overlay */}
      <AnimatePresence>
        {isOpen && (
          <div className="fixed inset-0 z-50 lg:hidden">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={onClose}
              className="absolute inset-0 bg-[var(--bg-overlay)]"
            />
            <motion.div 
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="absolute inset-y-0 left-0 w-64 h-full bg-[var(--bg-base)]"
            >
              {sidebarContent}
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  )
}